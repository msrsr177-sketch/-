import { initializeApp, getApp, getApps } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getMessaging } from "firebase/messaging";

// ملاحظة: يجب استبدال هذه القيم بقيم مشروعك الحقيقية من Firebase Console
const firebaseConfig = {
  apiKey: "AIzaSyAs-EXAMPLE-KEY",
  authDomain: "new-phone-app.firebaseapp.com",
  projectId: "new-phone-app",
  storageBucket: "new-phone-app.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef"
};

// تهيئة التطبيق - نتحقق أولاً إذا كان التطبيق مهيأ مسبقاً لمنع أخطاء التسجيل المتكرر
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

// تهيئة قاعدة البيانات Firestore باستخدام التطبيق المهيأ
export const db = getFirestore(app);

// تهيئة Firebase Messaging (قد يتطلب بيئة تدعم Service Workers في المتصفح)
export const messaging = typeof window !== 'undefined' ? getMessaging(app) : null;
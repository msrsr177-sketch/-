
import React from 'react';
import { DigitalProduct } from '../types';
import { Apple, DollarSign, Trophy, Luggage, Star, Monitor, Play } from 'lucide-react';

interface ProductCardProps {
  product: DigitalProduct;
  onClick: (product: DigitalProduct) => void;
}

const SolidGoldBg = "bg-[#FFD700]/30 backdrop-blur-[4px] border border-white/10 shadow-inner";

const AnimatedDice = () => (
  <div className={`flex items-center justify-center w-full h-full relative group ${SolidGoldBg}`}>
    <div className="dice-container">
      <div className="dice">
        <div className="dice-face face-1"><div className="dot"></div></div>
        <div className="dice-face face-2"><div className="dots-grid"><div className="dot" style={{gridArea:'1/1'}}></div><div className="dot" style={{gridArea:'3/3'}}></div></div></div>
        <div className="dice-face face-3"><div className="dots-grid"><div className="dot" style={{gridArea:'1/1'}}></div><div className="dot" style={{gridArea:'2/2'}}></div><div className="dot" style={{gridArea:'3/3'}}></div></div></div>
        <div className="dice-face face-4"><div className="dots-grid"><div className="dot" style={{gridArea:'1/1'}}></div><div className="dot" style={{gridArea:'1/3'}}></div><div className="dot" style={{gridArea:'3/1'}}></div><div className="dot" style={{gridArea:'3/3'}}></div></div></div>
        <div className="dice-face face-5"><div className="dots-grid"><div className="dot" style={{gridArea:'1/1'}}></div><div className="dot" style={{gridArea:'1/3'}}></div><div className="dot" style={{gridArea:'2/2'}}></div><div className="dot" style={{gridArea:'3/1'}}></div><div className="dot" style={{gridArea:'3/3'}}></div></div></div>
        <div className="dice-face face-6"><div className="dots-grid"><div className="dot" style={{gridArea:'1/1'}}></div><div className="dot" style={{gridArea:'1/3'}}></div><div className="dot" style={{gridArea:'2/1'}}></div><div className="dot" style={{gridArea:'2/3'}}></div><div className="dot" style={{gridArea:'3/1'}}></div><div className="dot" style={{gridArea:'3/3'}}></div></div></div>
      </div>
    </div>
  </div>
);

const AnimatedPubg = () => (
  <div className={`flex items-center justify-center w-full h-full relative group ${SolidGoldBg}`}>
    <div className="animate-bounce-short flex flex-col items-center">
      <div className="bg-white px-2 py-0.5 rounded-sm">
        <span className="text-black font-black text-[10px] tracking-tighter">PUBG</span>
      </div>
      <div className="text-[6px] font-black text-white mt-0.5 tracking-[0.2em]">MOBILE</div>
    </div>
  </div>
);

const AnimatedAppleLogo = () => (
  <div className={`flex items-center justify-center w-full h-full relative group ${SolidGoldBg}`}>
    <div className="animate-bounce-short">
      <Apple size={48} className="text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.4)]" />
    </div>
    <div className="absolute top-2 right-2 animate-bounce">
      <DollarSign size={20} className="text-[#FFD700] drop-shadow-[0_0_8px_rgba(255,215,0,0.6)]" />
    </div>
  </div>
);

const AnimatedTikTok = () => (
  <div className={`flex items-center justify-center w-full h-full relative group ${SolidGoldBg}`}>
    <div className="animate-bounce-short">
      <svg width="48" height="48" viewBox="0 0 24 24" fill="white">
        <path d="M19.589 6.686a4.793 4.793 0 01-3.77-4.245V2h-3.445v13.672a2.896 2.896 0 01-5.201 1.743l-.002-.001.002.001a2.895 2.895 0 013.183-4.51v-3.5a6.309 6.309 0 00-4.833 10.833 6.31 6.31 0 0010.833-4.433V9.132a8.213 8.213 0 005.388 1.934V7.63a4.706 4.706 0 01-2.155-.944z" />
      </svg>
    </div>
  </div>
);

const AnimatedRoblox = () => (
  <div className={`flex items-center justify-center w-full h-full relative group ${SolidGoldBg}`}>
    <div className="animate-bounce-short scale-110">
      <svg width="40" height="40" viewBox="0 0 100 100" fill="white">
        <path d="M22 0L0 78L78 100L100 22L22 0ZM62 62L38 56L44 32L68 38L62 62Z" />
      </svg>
    </div>
  </div>
);

const AnimatedVideoStar = () => (
  <div className={`flex items-center justify-center w-full h-full relative group ${SolidGoldBg}`}>
    <div className="animate-wiggle scale-110">
      <Star size={48} className="text-white fill-white drop-shadow-[0_0_15px_rgba(255,255,255,0.6)]" />
    </div>
  </div>
);

const AnimatedTOD = () => (
  <div className={`flex items-center justify-center w-full h-full relative group ${SolidGoldBg}`}>
    <div className="relative z-10 flex flex-col items-center">
      <div className="text-white font-black text-2xl tracking-tighter italic animate-bounce-short">TOD</div>
      <div className="absolute -bottom-1 -right-2 animate-spin-slow">
         <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-white drop-shadow-md">
            <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2"/>
            <path d="M12 2V22M2 12H22M5 5L19 19M19 5L5 19" stroke="currentColor" strokeWidth="1"/>
         </svg>
      </div>
    </div>
  </div>
);

const AnimatedAlManassa = () => (
  <div className={`flex items-center justify-center w-full h-full relative group ${SolidGoldBg}`}>
    <div className="animate-bounce-short relative">
      <Monitor size={48} className="text-white drop-shadow-lg" />
      <div className="absolute inset-0 flex items-center justify-center">
        <Play size={16} className="text-white fill-white translate-x-0.5" />
      </div>
    </div>
  </div>
);

const ProductCard: React.FC<ProductCardProps> = ({ product, onClick }) => {
  const isYallaLudo = product.id === 'yalla-ludo';
  const isApple = product.id === 'itunes-apple';
  const isTikTok = product.id === 'tiktok-coins';
  const isPubg = product.id === 'pubg-uc';
  const isRoblox = product.id === 'roblox';
  const isVideoStar = product.id === 'video-star';
  const isTOD = product.id === 'tod-tv';
  const isAlManassa = product.id === 'al-manassa';
  const isCrunchyroll = product.id === 'crunchyroll';

  return (
    <div 
      onClick={() => onClick(product)}
      className="glass rounded-[24px] cursor-pointer group hover:scale-[1.05] transition-all overflow-hidden flex flex-col h-full border border-white/10 shadow-lg"
    >
      <div className="w-full aspect-square overflow-hidden relative border-b border-white/5">
        {isYallaLudo ? <AnimatedDice /> : 
         isPubg ? <AnimatedPubg /> : 
         isApple ? <AnimatedAppleLogo /> : 
         isTikTok ? <AnimatedTikTok /> : 
         isRoblox ? <AnimatedRoblox /> :
         isVideoStar ? <AnimatedVideoStar /> :
         isTOD ? <AnimatedTOD /> :
         isAlManassa ? <AnimatedAlManassa /> :
         isCrunchyroll ? <div className={`${SolidGoldBg} flex items-center justify-center text-4xl`}>🎎</div> :
         <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
        }
      </div>
      <div className="p-3 flex-1 flex flex-col justify-between">
        <h3 className="text-[10px] md:text-xs font-black line-clamp-1">{product.name}</h3>
        <button className="w-full py-2 maroon-gradient rounded-xl font-black text-[9px] mt-2 shadow-lg shadow-red-900/20 active:scale-95 transition-all">شحن</button>
      </div>
    </div>
  );
};

export default ProductCard;

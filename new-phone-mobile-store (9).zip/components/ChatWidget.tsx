
import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Loader2, X, Sparkles } from 'lucide-react';
import { Message } from '../types';
import { chatWithGemini } from '../services/gemini';

interface ChatWidgetProps {
  onClose?: () => void;
}

const ChatWidget: React.FC<ChatWidgetProps> = ({ onClose }) => {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: 'يا هلا بيك عيوني بنبو فون! شلون أكدر أخدمك اليوم؟ صيانة لو شحن؟' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({
        top: scrollRef.current.scrollHeight,
        behavior: 'smooth'
      });
    }
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;
    const userMessage: Message = { role: 'user', text: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);
    
    // محاكاة تأخير بسيط للتفكير ليكون الرد واقعي
    const history = messages.map(m => ({
      role: m.role,
      parts: [{ text: m.text }]
    }));
    
    try {
      const response = await chatWithGemini(input, history);
      setMessages(prev => [...prev, { role: 'model', text: response }]);
    } catch (e) {
      setMessages(prev => [...prev, { role: 'model', text: 'آسف عيوني النت شوية فصل، عيد كلامك فدوة.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full glass-dark md:rounded-[40px] overflow-hidden border border-white/10 shadow-[0_25px_50px_-12px_rgba(0,0,0,0.5)] relative" dir="rtl">
      {/* Decorative background glow inside the chat */}
      <div className="absolute top-0 left-1/4 w-64 h-64 bg-red-600/10 rounded-full blur-[100px] pointer-events-none"></div>
      <div className="absolute bottom-0 right-1/4 w-64 h-64 bg-red-900/20 rounded-full blur-[100px] pointer-events-none"></div>

      <div className="maroon-gradient p-5 flex items-center justify-between shadow-lg relative z-10 border-b border-white/5">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 glass rounded-2xl flex items-center justify-center border border-white/20 shadow-inner">
            <Bot size={28} className="text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.5)]" />
          </div>
          <div className="text-right">
            <h3 className="font-black text-xl leading-tight text-white tracking-tight flex items-center gap-2">المساعد الذكي <Sparkles size={14} className="text-yellow-400 animate-pulse" /></h3>
            <div className="flex items-center gap-1.5 mt-0.5">
              <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(34,197,94,0.6)]"></span>
              <span className="text-[10px] font-bold uppercase tracking-widest text-white/60">خبير نيو فون متاح الآن</span>
            </div>
          </div>
        </div>
        {onClose && (
          <button 
            onClick={onClose} 
            className="glass hover:bg-white/10 p-2.5 rounded-xl transition-all active:scale-90 border border-white/10"
          >
            <X className="w-6 h-6 text-white" />
          </button>
        )}
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-5 space-y-6 relative z-10 no-scrollbar">
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === 'user' ? 'justify-start' : 'justify-end'} animate-in fade-in slide-in-from-bottom-2 duration-300`}>
            <div className={`flex gap-3 max-w-[85%] ${msg.role === 'user' ? 'flex-row' : 'flex-row-reverse'}`}>
              <div className={`w-10 h-10 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg border ${
                msg.role === 'user' 
                  ? 'maroon-gradient border-white/10 text-white' 
                  : 'glass-dark border-red-500/20 text-red-500'
              }`}>
                {msg.role === 'user' ? <User size={20} /> : <Bot size={20} />}
              </div>
              <div className={`p-4 rounded-[25px] text-sm leading-relaxed text-right font-medium shadow-sm border ${
                msg.role === 'user' 
                  ? 'bg-red-900/30 text-white rounded-tl-none border-red-500/20 shadow-lg shadow-red-900/10' 
                  : 'glass rounded-tr-none border-white/10 text-white/90'
              }`}>
                {msg.text}
              </div>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-end animate-pulse">
            <div className="glass p-4 rounded-2xl rounded-tr-none flex items-center gap-3 border border-white/10">
              <Loader2 className="w-4 h-4 animate-spin text-red-500" />
              <span className="text-xs text-white/40 font-black italic">جاري كتابة الرد...</span>
            </div>
          </div>
        )}
      </div>

      <div className="p-5 bg-white/5 backdrop-blur-3xl border-t border-white/10 relative z-10">
        <div className="relative group">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="اكتب استفسارك هنا عيوني..."
            className="w-full bg-black/40 border border-white/10 rounded-[22px] py-5 px-6 pl-16 text-right text-sm font-bold focus:outline-none focus:border-red-500/50 focus:ring-4 focus:ring-red-500/5 transition-all placeholder:text-white/20 text-white"
          />
          <button 
            onClick={handleSend}
            disabled={isLoading || !input.trim()}
            className="absolute left-2.5 top-2.5 bottom-2.5 aspect-square maroon-gradient rounded-xl flex items-center justify-center hover:scale-105 active:scale-95 disabled:opacity-30 disabled:grayscale transition-all shadow-xl shadow-red-900/30"
          >
            <Send className="w-6 h-6 rotate-180 text-white" />
          </button>
        </div>
        <p className="text-center text-[9px] text-white/20 mt-4 font-medium tracking-tight">تنبيه: نيو فون يخدمكم بكل أمان وسرعة.</p>
      </div>
    </div>
  );
};

export default ChatWidget;

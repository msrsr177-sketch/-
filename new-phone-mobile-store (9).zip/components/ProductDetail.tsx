
import React, { useState, useEffect } from 'react';
import { DigitalProduct, ProductPackage } from '../types';
import { ChevronRight, Zap, ShieldCheck, CheckCircle2, ArrowLeft, Star, Apple, DollarSign, Trophy, Luggage, Monitor, Play } from 'lucide-react';

interface ProductDetailProps {
  product: DigitalProduct;
  onBack: () => void;
}

const SolidGoldHeaderBg = "bg-[#FFD700]/40 backdrop-blur-[8px]";

const AnimatedDiceHeader = () => (
  <div className={`flex items-center justify-center w-full h-full relative overflow-hidden ${SolidGoldHeaderBg}`}>
    <div className="dice-container" style={{ width: '100px', height: '100px' }}>
      <div className="dice" style={{ animationDuration: '6s' }}>
        {[1, 2, 3, 4, 5, 6].map((num) => (
          <div key={num} className={`dice-face face-${num}`} style={{ width: '100px', height: '100px', transform: num <= 3 ? `rotateY(${(num-1)*90}deg) translateZ(50px)` : (num === 4 ? 'rotateY(-90deg) translateZ(50px)' : (num === 5 ? 'rotateX(90deg) translateZ(50px)' : 'rotateX(-90deg) translateZ(50px)')), background: '#FFD700' }}>
            <div className={num === 1 ? "" : "dots-grid"} style={{ width: '70px', height: '70px' }}>
               {num === 1 && <div className="dot" style={{ width: '15px', height: '15px' }}></div>}
               {num > 1 && <div className="dot" style={{ width: '15px', height: '15px' }}></div>}
            </div>
          </div>
        ))}
      </div>
    </div>
  </div>
);

const AnimatedPubgHeader = () => (
  <div className={`flex items-center justify-center w-full h-full relative overflow-hidden ${SolidGoldHeaderBg}`}>
    <div className="relative z-10 flex flex-col items-center scale-[2.5]">
      <div className="animate-bounce-short flex flex-col items-center">
        <div className="bg-white px-4 py-1 rounded-md shadow-2xl">
           <span className="text-black font-black text-2xl tracking-tighter">PUBG</span>
        </div>
        <div className="text-[10px] font-black text-white mt-1 tracking-[0.4em]">MOBILE</div>
      </div>
    </div>
  </div>
);

const AnimatedAppleHeader = () => (
  <div className={`flex items-center justify-center w-full h-full relative overflow-hidden ${SolidGoldHeaderBg}`}>
    <div className="relative z-10 flex items-center justify-center scale-[2.5] animate-bounce-short">
      <Apple size={60} className="text-white drop-shadow-[0_0_20px_rgba(255,255,255,0.5)]" />
    </div>
  </div>
);

const AnimatedTikTokHeader = () => (
  <div className={`flex items-center justify-center w-full h-full relative overflow-hidden ${SolidGoldHeaderBg}`}>
    <div className="relative z-10 animate-bounce-short scale-[3]">
      <svg width="40" height="40" viewBox="0 0 24 24" fill="white">
        <path d="M19.589 6.686a4.793 4.793 0 01-3.77-4.245V2h-3.445v13.672a2.896 2.896 0 01-5.201 1.743l-.002-.001.002.001a2.895 2.895 0 013.183-4.51v-3.5a6.309 6.309 0 00-4.833 10.833 6.31 6.31 0 0010.833-4.433V9.132a8.213 8.213 0 005.388 1.934V7.63a4.706 4.706 0 01-2.155-.944z" />
      </svg>
    </div>
  </div>
);

const AnimatedVideoStarHeader = () => (
  <div className={`flex items-center justify-center w-full h-full relative overflow-hidden ${SolidGoldHeaderBg}`}>
    <div className="relative z-10 scale-[4] animate-wiggle">
      <Star size={40} className="text-white fill-white drop-shadow-2xl" />
    </div>
  </div>
);

const AnimatedTODHeader = () => (
  <div className={`flex items-center justify-center w-full h-full relative overflow-hidden ${SolidGoldHeaderBg}`}>
    <div className="relative z-10 flex flex-col items-center scale-[3]">
      <div className="text-white font-black text-2xl italic animate-bounce-short">TOD</div>
      <div className="mt-2 animate-spin-slow">
         <svg width="20" height="20" viewBox="0 0 24 24" fill="white">
            <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2"/>
            <path d="M12 2V22M2 12H22" stroke="currentColor" strokeWidth="1"/>
         </svg>
      </div>
    </div>
  </div>
);

const AnimatedAlManassaHeader = () => (
  <div className={`flex items-center justify-center w-full h-full relative overflow-hidden ${SolidGoldHeaderBg}`}>
    <div className="relative z-10 scale-[4] animate-bounce-short">
      <Monitor size={40} className="text-white drop-shadow-2xl" />
      <div className="absolute inset-0 flex items-center justify-center translate-y-[-2px]">
        <Play size={12} className="text-white fill-white translate-x-0.5" />
      </div>
    </div>
  </div>
);

const ProductDetail: React.FC<ProductDetailProps> = ({ product, onBack }) => {
  const [toast, setToast] = useState<{ show: boolean; pkgName: string | null }>({
    show: false,
    pkgName: null,
  });

  const isYallaLudo = product.id === 'yalla-ludo';
  const isApple = product.id === 'itunes-apple';
  const isTikTok = product.id === 'tiktok-coins';
  const isPubg = product.id === 'pubg-uc';
  const isVideoStar = product.id === 'video-star';
  const isTOD = product.id === 'tod-tv';
  const isAlManassa = product.id === 'al-manassa';

  const groups = product.packages.reduce((acc: Record<string, ProductPackage[]>, pkg) => {
    const groupName = pkg.group || 'default';
    if (!acc[groupName]) acc[groupName] = [];
    acc[groupName].push(pkg);
    return acc;
  }, {} as Record<string, ProductPackage[]>);

  const handlePackageSelect = (pkg: ProductPackage) => {
    setToast({ show: true, pkgName: pkg.amount });
  };

  useEffect(() => {
    if (toast.show) {
      const timer = setTimeout(() => {
        setToast((prev) => ({ ...prev, show: false }));
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [toast.show]);

  const renderPackage = (pkg: ProductPackage) => {
    const isCyan = pkg.color === 'cyan';
    const priceColor = isCyan ? 'text-sky-400' : 'text-[#FFD700]';
    return (
      <div 
        key={pkg.id} 
        onClick={() => handlePackageSelect(pkg)}
        className={`glass-dark p-5 rounded-[28px] flex flex-col items-center justify-center text-center border border-white/5 hover:border-red-500/30 transition-all cursor-pointer group active:scale-95 shadow-lg`}
      >
        <div className="relative z-10">
          <div className="font-black text-lg text-white mb-1">{pkg.amount}</div>
          <div className={`${priceColor} font-black text-base`}>{pkg.price}</div>
          <div className="text-white/20 text-[8px] mt-1 font-bold uppercase">{pkg.name}</div>
        </div>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#1A0000] overflow-y-auto pb-32 no-scrollbar" dir="rtl">
      <div className="max-w-md mx-auto min-h-screen relative">
        <div className="relative h-72">
          {isYallaLudo ? <AnimatedDiceHeader /> : 
           isPubg ? <AnimatedPubgHeader /> : 
           isApple ? <AnimatedAppleHeader /> : 
           isTikTok ? <AnimatedTikTokHeader /> : 
           isVideoStar ? <AnimatedVideoStarHeader /> :
           isTOD ? <AnimatedTODHeader /> :
           isAlManassa ? <AnimatedAlManassaHeader /> :
           <img src={product.image} className="w-full h-full object-cover" alt={product.name} />
          }
          <div className="absolute inset-0 bg-gradient-to-t from-[#1A0000] via-[#1A0000]/20 to-transparent" />
          <div className="absolute top-0 left-0 right-0 p-6 flex justify-between items-center z-20">
             <div className="glass px-4 py-2 rounded-full border border-white/10 flex items-center gap-2">
                <Star className="text-yellow-500 w-3 h-3 fill-current" />
                <span className="text-[10px] font-black">أفضل الأسعار</span>
             </div>
             <button onClick={onBack} className="glass p-3 rounded-2xl border border-white/10 shadow-lg">
                <ChevronRight className="w-6 h-6 text-white" />
              </button>
          </div>
        </div>

        <div className="px-5 -mt-16 relative z-10">
          <div className="glass p-8 rounded-[40px] border border-white/10 mb-8 shadow-2xl">
            <h1 className="text-3xl font-black mb-2">{product.name}</h1>
            <p className="text-white/60 text-sm leading-relaxed">{product.description}</p>
            <div className="flex items-center gap-2.5 mt-4 glass-dark w-fit px-4 py-2 rounded-2xl border border-white/5">
              <ShieldCheck className="w-4 h-4 text-green-500" />
              <span className="text-[10px] font-black text-green-400">شحن فوري بالـ ID</span>
            </div>
          </div>

          <div className="space-y-10">
            {Object.entries(groups).map(([groupName, packages]) => (
              <div key={groupName} className="space-y-5">
                <div className="flex items-center gap-3 px-2">
                   <div className="w-1.5 h-6 rounded-full bg-red-500 shadow-lg"></div>
                   <h2 className="text-xl font-black">{groupName === 'default' ? 'اختر الحزمة' : groupName}</h2>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  {(packages as ProductPackage[]).map(renderPackage)}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className={`fixed bottom-8 left-4 right-4 z-[60] transition-all duration-500 transform ${toast.show ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0 pointer-events-none'}`}>
        <div className="max-w-md mx-auto glass-dark border border-white/10 p-5 rounded-[35px] shadow-2xl flex items-center justify-between gap-4 backdrop-blur-2xl">
          <div className="flex items-center gap-4 text-right">
            <div className="w-12 h-12 bg-green-500/10 rounded-2xl flex items-center justify-center border border-green-500/20">
              <CheckCircle2 className="text-green-500 w-7 h-7" />
            </div>
            <div>
              <p className="text-[10px] opacity-40 font-black">تأكيد الاختيار</p>
              <p className="text-base font-black">{toast.pkgName}</p>
            </div>
          </div>
          <button onClick={() => alert('سيتم توجيهك للواتساب')} className="maroon-gradient px-8 py-4 rounded-2xl font-black text-xs flex items-center gap-2.5 shadow-xl shadow-red-900/40">
            إتمام الطلب
            <ArrowLeft className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;

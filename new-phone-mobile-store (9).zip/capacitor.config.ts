import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.newphone.app',
  appName: 'New Phone',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: "#1A0000",
      showSpinner: true,
      androidSpinnerStyle: "large",
      iosSpinnerStyle: "small",
      spinnerColor: "#800000"
    }
  },
  android: {
    allowMixedContent: true,
    buildOptions: {
      releaseType: 'AAB'
    }
  },
  ios: {
    contentInset: 'always'
  }
};

export default config;
import React, { useState, useRef, useEffect } from 'react';
import { 
  Home, Gift, Disc, Megaphone, Phone, MessageSquare, LayoutGrid, 
  Smartphone, Cpu, ShieldCheck, Sparkles, Zap, Package, 
  Bell, X, Star, Cloud, Calendar, Image as ImageIcon, Send, Clock, Users, Monitor, Gamepad2, CreditCard,
  DollarSign, FileText, PlusCircle, ArrowLeft, ChevronLeft, Heart, Instagram, Facebook, Camera, Info, Loader2, BellRing
} from 'lucide-react';
import { AppMenu, DigitalProduct } from './types';
import { DIGITAL_PRODUCTS as FALLBACK_PRODUCTS } from './constants';
import ProductCard from './components/ProductCard';
import ProductDetail from './components/ProductDetail';
import ChatWidget from './components/ChatWidget';
import WheelOfFortune from './components/WheelOfFortune';
import { db, messaging } from './firebaseConfig';
import { collection, onSnapshot, query } from 'firebase/firestore';
import { onMessage } from 'firebase/messaging';

const INITIAL_NOTIFICATIONS = [
  { id: 6, title: 'تيم التوحد', message: 'حمد + احمد يرحبون بكم في تطبيق نيو فون الرسمي.', icon: <Users size={16} />, time: 'الآن' },
  { id: 5, title: 'رسالة من حمد', message: 'أهلاً وسهلاً بكم، نسعد بخدمتكم وتوفير أفضل العروض لكم.', icon: <Star size={16} />, time: 'منذ دقيقتين' },
  { id: 1, title: 'تخفيضات كبرى!', message: 'خصم 15% على جميع شدات ببجي لفترة محدودة.', icon: <DollarSign size={16} />, time: 'منذ ساعة' },
];

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<AppMenu>(AppMenu.HOME);
  const [products, setProducts] = useState<DigitalProduct[]>(FALLBACK_PRODUCTS);
  const [loadingProducts, setLoadingProducts] = useState(true);
  const [selectedProduct, setSelectedProduct] = useState<DigitalProduct | null>(null);
  const [showChat, setShowChat] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState(INITIAL_NOTIFICATIONS);
  const [unreadCount, setUnreadCount] = useState(0);
  const [showHomeAdForm, setShowHomeAdForm] = useState(false);
  const [activeToast, setActiveToast] = useState<{title: string, msg: string} | null>(null);
  const [showPermissionPrompt, setShowPermissionPrompt] = useState(false);

  const [adForm, setAdForm] = useState({ 
    userName: '', 
    phone: '', 
    productName: '', 
    price: '',
    description: '' 
  });

  const [icloudForm, setIcloudForm] = useState({ 
    name: '', 
    phone: '', 
    birthDate: '', 
    image: null as File | null 
  });

  const notificationRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // 1. طلب إذن الإشعارات عند التشغيل الأول
    const checkNotificationPermission = async () => {
      if ('Notification' in window) {
        if (Notification.permission === 'default') {
          // تأخير بسيط لإظهار النافذة المنبثقة بشكل أنيق
          setTimeout(() => setShowPermissionPrompt(true), 3000);
        }
      }
    };
    checkNotificationPermission();

    // 2. معالجة الرسائل في المقدمة (Foreground Messaging)
    if (messaging) {
      onMessage(messaging, (payload) => {
        console.log('Message received. ', payload);
        const newNotif = {
          id: Date.now(),
          title: payload.notification?.title || 'تنبيه جديد',
          message: payload.notification?.body || '',
          icon: <BellRing size={16} />,
          time: 'الآن'
        };
        setNotifications(prev => [newNotif, ...prev]);
        setUnreadCount(prev => prev + 1);
        setActiveToast({
          title: payload.notification?.title || 'تنبيه جديد',
          msg: payload.notification?.body || ''
        });
      });
    }

    // 3. مزامنة حية للمنتجات من Firestore
    let unsubscribe = () => {};
    try {
      const productsRef = collection(db, 'products');
      const q = query(productsRef);

      unsubscribe = onSnapshot(q, (snapshot) => {
        const fetchedProducts: any[] = [];
        snapshot.forEach((doc) => {
          fetchedProducts.push({ id: doc.id, ...doc.data() });
        });
        
        if (fetchedProducts.length > 0) {
          setProducts(fetchedProducts as DigitalProduct[]);
        }
        setLoadingProducts(false);
      }, (error) => {
        console.warn("Firestore access issues (using fallback data):", error);
        setLoadingProducts(false);
      });
    } catch (err) {
      console.error("Firebase Initialization error:", err);
      setLoadingProducts(false);
    }

    // إشعار ترحيبي
    const welcomeTimer = setTimeout(() => {
      setActiveToast({
        title: 'يا هلا بيك عيوني!',
        msg: 'نيو فون متاح لخدمتك دائماً. جرب المساعد الذكي للحصول على إجابات سريعة.'
      });
      setUnreadCount(prev => prev + 1);
    }, 4500);

    const handleClickOutside = (event: MouseEvent) => {
      if (notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
        setShowNotifications(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    
    return () => {
      unsubscribe();
      clearTimeout(welcomeTimer);
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const requestPermission = async () => {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        setActiveToast({ title: 'تم التفعيل', msg: 'ستصلك الآن عروض نيو فون أولاً بأول!' });
      }
      setShowPermissionPrompt(false);
    }
  };

  const closeToast = () => setActiveToast(null);

  const renderContent = () => {
    switch (activeTab) {
      case AppMenu.HOME:
        return (
          <div className="space-y-8 animate-in fade-in duration-700 pb-10">
            {/* الهيرو */}
            <div className="relative glass p-10 md:p-14 rounded-[45px] overflow-hidden border border-white/10 shadow-2xl text-center">
              <div className="absolute inset-0 maroon-gradient opacity-10"></div>
              <div className="relative z-10 space-y-4">
                <div className="animated-logo-container">
                  <h2 className="text-5xl md:text-6xl font-black shiny-logo">نيو فون</h2>
                  <p className="text-red-500 font-black tracking-[0.2em] uppercase text-sm mt-1">NEW PHONE</p>
                </div>
                <p className="text-white/70 max-w-lg mx-auto leading-relaxed text-base font-medium">
                  المكان الأمثل لصيانة وبرمجة الهواتف وشحن البطاقات الرقمية في ميسان.
                </p>
                <div className="flex flex-wrap justify-center gap-3">
                  <div className="glass px-5 py-2 rounded-[20px] border border-white/10 flex items-center gap-2">
                    <ShieldCheck className="text-green-500 w-4 h-4" />
                    <span className="text-xs font-black">جودة مضمونة</span>
                  </div>
                  <div className="glass px-5 py-2 rounded-[20px] border border-white/10 flex items-center gap-2">
                    <Zap className="text-yellow-500 w-4 h-4" />
                    <span className="text-xs font-black">شحن بالثانية</span>
                  </div>
                </div>
              </div>
            </div>

            {/* الإعلانات وعجلة الحظ */}
            <div className="grid grid-cols-2 gap-4">
              <div 
                onClick={() => setShowHomeAdForm(!showHomeAdForm)}
                className={`relative glass rounded-[40px] p-6 border transition-all shadow-xl cursor-pointer group flex flex-col items-center justify-center text-center ${showHomeAdForm ? 'border-red-500/50 bg-red-500/5' : 'border-white/10 hover:border-red-500/30'}`}
              >
                <div className="w-14 h-14 maroon-gradient rounded-[22px] flex items-center justify-center mb-3 shadow-lg group-hover:scale-110 transition-transform">
                  <Megaphone className="text-white" size={28} />
                </div>
                <h3 className="text-sm font-black">إعلانات الزبائن</h3>
                <p className="text-[9px] text-white/40 mt-1">أضف إعلانك الآن</p>
              </div>

              <div 
                onClick={() => setActiveTab(AppMenu.WHEEL)}
                className="relative glass rounded-[40px] p-6 border border-white/10 transition-all shadow-xl cursor-pointer group flex flex-col items-center justify-center text-center hover:border-yellow-500/30"
              >
                <div className="w-14 h-14 maroon-gradient rounded-[22px] flex items-center justify-center mb-3 shadow-lg group-hover:rotate-12 transition-transform">
                  <Disc className="text-yellow-500" size={28} />
                </div>
                <h3 className="text-sm font-black">عجلة الحظ</h3>
                <p className="text-[9px] text-white/40 mt-1">اربح هدايا فورية</p>
              </div>
            </div>

            {showHomeAdForm && (
              <div className="space-y-6 animate-in slide-in-from-top-4 duration-500">
                <div className="glass p-8 rounded-[45px] border border-white/10 shadow-2xl relative overflow-hidden">
                  <button onClick={() => setShowHomeAdForm(false)} className="absolute top-6 left-6 text-white/30 hover:text-white transition-colors">
                    <X size={20} />
                  </button>
                  <div className="text-center mb-8">
                    <h3 className="text-xl font-black">أضف إعلانك الخاص</h3>
                    <p className="text-white/40 text-sm mt-2 font-medium">اعرض جهازك للبيع في مكتبنا</p>
                  </div>
                  <form onSubmit={(e) => { e.preventDefault(); alert('تم استلام إعلانك!'); setShowHomeAdForm(false); }} className="space-y-5">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                      <input type="text" placeholder="اسم المعلن" required className="bg-black/40 border border-white/5 rounded-2xl py-4 px-6 text-white focus:outline-none focus:border-red-500" value={adForm.userName} onChange={e => setAdForm({...adForm, userName: e.target.value})} />
                      <input type="tel" placeholder="رقم الهاتف" required className="bg-black/40 border border-white/5 rounded-2xl py-4 px-6 text-white focus:outline-none focus:border-red-500" value={adForm.phone} onChange={e => setAdForm({...adForm, phone: e.target.value})} />
                    </div>
                    <input type="text" placeholder="اسم الجهاز" required className="w-full bg-black/40 border border-white/5 rounded-2xl py-4 px-6 text-white focus:outline-none focus:border-red-500" value={adForm.productName} onChange={e => setAdForm({...adForm, productName: e.target.value})} />
                    <button type="submit" className="w-full maroon-gradient py-5 rounded-2xl font-black text-lg shadow-xl shadow-red-900/40 border border-white/10 active:scale-95 transition-all">نشر الإعلان</button>
                  </form>
                </div>
              </div>
            )}

            {/* خدماتنا */}
            <div className="space-y-6 pt-4">
               <h3 className="text-xl font-black px-4 flex items-center gap-2"><Sparkles size={20} className="text-red-500" /> خدماتنا الاحترافية</h3>
               <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[
                    { title: 'صيانة هاردوير', icon: <Smartphone className="text-blue-400" />, desc: 'تبديل شاشات وبطاريات' },
                    { title: 'برمجة سوفتوير', icon: <Cpu className="text-purple-400" />, desc: 'تخطي حسابات وفورمات' },
                    { title: 'شحن ألعاب', icon: <Gamepad2 className="text-red-400" />, desc: 'ببجي ولودو وتيك توك' },
                    { title: 'بطاقات رقمية', icon: <CreditCard className="text-orange-400" />, desc: 'آيتونز وجوجل بلاي' }
                  ].map((s, idx) => (
                    <div key={idx} className="glass p-6 rounded-[35px] border border-white/5 hover:scale-105 transition-all text-center group">
                      <div className="w-14 h-14 maroon-gradient mx-auto rounded-[22px] flex items-center justify-center mb-4 shadow-lg group-hover:rotate-6 transition-transform">{s.icon}</div>
                      <h3 className="text-sm font-black">{s.title}</h3>
                      <p className="text-[9px] text-white/30 mt-1">{s.desc}</p>
                    </div>
                  ))}
                </div>
            </div>

            <div className="pt-8 text-center animate-in fade-in slide-in-from-bottom-2 duration-1000">
               <div className="glass-dark inline-flex items-center gap-3 px-6 py-4 rounded-[25px] border border-white/5 shadow-lg">
                  <Heart size={14} className="text-red-600 animate-pulse fill-red-600" />
                  <p className="text-xs font-black tracking-wide text-white/60">
                     تم إنشاء التطبيق بواسطة <span className="text-red-500">الدكتور حمد</span>
                  </p>
               </div>
            </div>
          </div>
        );
      case AppMenu.SERVICES:
        return (
          <div className="space-y-6 animate-in fade-in duration-500 pb-10">
            <h2 className="text-2xl font-black px-2 flex items-center gap-2 text-white">
              <LayoutGrid size={24} className="text-red-500" /> المنتجات الرقمية
            </h2>
            {loadingProducts ? (
              <div className="flex flex-col items-center justify-center py-20 gap-6">
                <div className="relative">
                  <div className="w-20 h-20 border-4 border-red-500/20 border-t-red-500 rounded-full animate-spin"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Loader2 className="w-8 h-8 text-red-500 animate-pulse" />
                  </div>
                </div>
                <div className="text-center">
                   <p className="text-lg font-black text-white">جاري الاتصال بـ نيو فون...</p>
                   <p className="text-sm font-bold text-white/40 mt-1 italic">نقوم بتحديث الأسعار فورياً من أجلك عيوني.</p>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
                {products.map(p => (
                  <ProductCard key={p.id} product={p} onClick={setSelectedProduct} />
                ))}
              </div>
            )}
          </div>
        );
      case AppMenu.ICLOUD:
        return (
          <div className="space-y-8 animate-in fade-in duration-500 pb-10">
            <h2 className="text-2xl font-black px-4 flex items-center gap-2"><Cloud className="text-red-500" /> خدمات آيكلود</h2>
            
            <div className="glass p-6 rounded-[30px] border border-green-500/20 bg-green-500/5 flex items-center gap-4 mx-auto max-w-xl">
               <ShieldCheck className="text-green-500 flex-shrink-0" size={32} />
               <p className="text-xs md:text-sm font-black text-green-400 leading-relaxed">
                  نيو فون هو اختيارك الأول لضمان الأمان والخصوصية.. نضمن لكم أماناً تاماً وخصوصية مطلقة في كافة خدماتنا الرقمية.
               </p>
            </div>

            <div className="glass p-10 rounded-[40px] border border-white/10 shadow-xl max-w-xl mx-auto">
              <div className="text-center mb-8">
                <div className="w-16 h-16 maroon-gradient rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <PlusCircle className="text-white w-8 h-8" />
                </div>
                <h3 className="text-xl font-black">إنشاء حساب آبل جديد</h3>
              </div>
              <form onSubmit={(e) => { e.preventDefault(); alert('تم استلام طلبك!'); }} className="space-y-6">
                <input type="text" placeholder="الاسم الكامل" required className="w-full bg-black/40 border border-white/5 rounded-2xl py-4 px-6 text-white focus:outline-none focus:border-red-500" value={icloudForm.name} onChange={e => setIcloudForm({...icloudForm, name: e.target.value})} />
                <input type="tel" placeholder="رقم الهاتف" required className="w-full bg-black/40 border border-white/5 rounded-2xl py-4 px-6 text-white focus:outline-none focus:border-red-500" value={icloudForm.phone} onChange={e => setIcloudForm({...icloudForm, phone: e.target.value})} />
                <input type="text" placeholder="المواليد الكاملة" required className="w-full bg-black/40 border border-white/5 rounded-2xl py-4 px-6 text-white focus:outline-none focus:border-red-500" value={icloudForm.birthDate} onChange={e => setIcloudForm({...icloudForm, birthDate: e.target.value})} />
                
                <label className="block w-full cursor-pointer bg-black/40 border border-white/5 border-dashed border-2 rounded-2xl py-6 text-center hover:bg-white/5 transition-all">
                  <input type="file" accept="image/*" className="hidden" onChange={(e) => setIcloudForm({...icloudForm, image: e.target.files ? e.target.files[0] : null})} />
                  <Camera className="mx-auto text-white/30 mb-2" size={24} />
                  <span className="text-[10px] font-black text-white/40">{icloudForm.image ? icloudForm.image.name : 'صورة الهوية (اختياري)'}</span>
                </label>

                <button type="submit" className="w-full maroon-gradient py-5 rounded-2xl font-black text-xl shadow-xl active:scale-95 transition-all">إرسال الطلب</button>
              </form>
            </div>
          </div>
        );
      case AppMenu.CONTACT:
        return (
          <div className="space-y-8 animate-in fade-in duration-500 pb-10">
            <h2 className="text-2xl font-black flex items-center gap-2"><Phone className="text-red-500" /> تواصل معنا</h2>
            <div className="glass p-8 rounded-[40px] flex items-center gap-5 border border-white/10 shadow-xl">
              <div className="p-5 maroon-gradient rounded-[22px] shadow-lg"><Monitor className="text-white" /></div>
              <div>
                <p className="text-xs opacity-40 font-black">موقعنا</p>
                <p className="text-lg font-black">ميسان - حي الزهراء - مجاور مكتبة المتنبي</p>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
               {[ 
                 { name: 'حمد', phone: '07722655734' }, 
                 { name: 'حمزة', phone: '07710557578' },
                 { name: 'حيدر', phone: '07711150176' } 
               ].map((c, i) => (
                 <a key={i} href={`tel:${c.phone}`} className="glass p-6 rounded-[30px] flex justify-between items-center group">
                    <span className="font-black">{c.name}</span>
                    <span className="font-mono text-red-500 font-black">{c.phone}</span>
                 </a>
               ))}
            </div>
          </div>
        );
      case AppMenu.WHEEL:
        return <div className="pb-10"><WheelOfFortune /></div>;
      default: return null;
    }
  };

  return (
    <div className="min-h-screen pb-40 selection:bg-red-500 selection:text-white relative overflow-hidden">
      
      {/* نافذة طلب إذن الإشعارات */}
      {showPermissionPrompt && (
        <div className="fixed inset-0 z-[110] bg-black/80 backdrop-blur-md flex items-center justify-center p-6 animate-in fade-in duration-500">
           <div className="glass-dark border border-white/10 p-8 rounded-[45px] max-w-sm w-full text-center space-y-6 shadow-2xl">
              <div className="w-20 h-20 maroon-gradient rounded-full flex items-center justify-center mx-auto shadow-lg animate-bounce-short">
                <BellRing size={40} className="text-white" />
              </div>
              <div className="space-y-2">
                <h3 className="text-2xl font-black">أبقى على اطلاع!</h3>
                <p className="text-sm font-bold text-white/50 leading-relaxed italic">
                  عيوني فعل الإشعارات حتى توصلك آخر عروض الشحن وصيانة جهازك فوراً.
                </p>
              </div>
              <div className="space-y-3 pt-4">
                <button 
                  onClick={requestPermission}
                  className="w-full maroon-gradient py-4 rounded-2xl font-black text-lg shadow-xl shadow-red-900/40 active:scale-95 transition-all"
                >
                  تفعيل الإشعارات
                </button>
                <button 
                  onClick={() => setShowPermissionPrompt(false)}
                  className="w-full py-4 glass rounded-2xl font-black text-sm text-white/40 hover:text-white transition-colors"
                >
                  ليس الآن
                </button>
              </div>
           </div>
        </div>
      )}

      {activeToast && (
        <div className="fixed top-24 left-4 right-4 z-[100] animate-in slide-in-from-top-full duration-500">
          <div className="max-w-md mx-auto glass-dark p-4 rounded-[25px] border border-red-500/30 flex items-center gap-4 shadow-2xl">
            <div className="w-10 h-10 rounded-xl maroon-gradient flex items-center justify-center text-white"><Info size={20} /></div>
            <div className="flex-1">
              <h4 className="text-xs font-black">{activeToast.title}</h4>
              <p className="text-[10px] text-white/60">{activeToast.msg}</p>
            </div>
            <button onClick={closeToast} className="p-2 text-white/30 hover:text-white"><X size={16} /></button>
          </div>
        </div>
      )}

      <header className="fixed top-0 left-0 right-0 z-50 glass-dark px-6 py-5 flex items-center justify-between border-b border-white/5 shadow-lg">
        <h1 className="text-2xl font-black shiny-logo tracking-tighter cursor-pointer" onClick={() => setActiveTab(AppMenu.HOME)}>نيو فون</h1>
        <div className="flex items-center gap-3">
          <div className="relative" ref={notificationRef}>
            <button onClick={() => { setShowNotifications(!showNotifications); setUnreadCount(0); }} className={`p-3.5 rounded-[22px] glass border border-white/10 transition-all active:scale-90 relative ${unreadCount > 0 ? 'bg-red-500/10 border-red-500/20 shadow-lg' : ''}`}>
              <Bell className={`w-5 h-5 ${unreadCount > 0 ? 'text-red-500 animate-pulse' : 'text-white'}`} />
              {unreadCount > 0 && <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-600 rounded-full text-[8px] flex items-center justify-center font-black animate-bounce shadow-lg">{unreadCount}</span>}
            </button>
            {showNotifications && (
              <div className="absolute top-full left-0 mt-4 w-80 glass-dark border border-white/10 rounded-[35px] shadow-2xl overflow-hidden z-[60]">
                <div className="maroon-gradient p-5 font-black text-sm text-white flex justify-between items-center">
                   <span>تنبيهات نيو فون</span>
                   {unreadCount > 0 && <span className="text-[9px] bg-white/20 px-2 py-0.5 rounded-full">{unreadCount} جديد</span>}
                </div>
                <div className="max-h-80 overflow-y-auto no-scrollbar">
                  {notifications.map(n => (
                    <div key={n.id} className="p-5 border-b border-white/5 flex gap-4 hover:bg-white/5 transition-colors">
                      <div className="w-10 h-10 rounded-2xl bg-red-500/10 flex items-center justify-center text-red-500">{n.icon}</div>
                      <div>
                        <h4 className="text-xs font-black text-white">{n.title}</h4>
                        <p className="text-[10px] text-white/50 leading-relaxed mt-1">{n.message}</p>
                        <p className="text-[8px] text-white/20 mt-2 font-bold uppercase">{n.time}</p>
                      </div>
                    </div>
                  ))}
                  {notifications.length === 0 && (
                    <div className="p-10 text-center">
                       <p className="text-white/20 text-xs font-black italic">لا توجد تنبيهات حالياً عيوني.</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
          <button onClick={() => setShowChat(true)} className="maroon-gradient p-3.5 rounded-[22px] shadow-xl hover:scale-110 active:scale-90 transition-all">
            <MessageSquare size={22} className="text-white" />
          </button>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 pt-32">
        {renderContent()}
      </main>

      <nav className="fixed bottom-6 left-6 right-6 z-50 glass-dark rounded-[35px] p-2 flex justify-around border border-white/10 shadow-2xl">
        <NavButton active={activeTab === AppMenu.SERVICES} icon={<LayoutGrid size={22} />} label="المنتجات" onClick={() => setActiveTab(AppMenu.SERVICES)} />
        <NavButton active={activeTab === AppMenu.ICLOUD} icon={<Cloud size={22} />} label="آيكلود" onClick={() => setActiveTab(AppMenu.ICLOUD)} />
        <NavButton active={activeTab === AppMenu.HOME} icon={<Home size={22} />} label="الرئيسية" onClick={() => setActiveTab(AppMenu.HOME)} />
        <NavButton active={activeTab === AppMenu.CONTACT} icon={<Phone size={22} />} label="تواصل" onClick={() => setActiveTab(AppMenu.CONTACT)} />
      </nav>

      {selectedProduct && <ProductDetail product={selectedProduct} onBack={() => setSelectedProduct(null)} />}
      {showChat && (
        <div className="fixed inset-0 z-[100] bg-black/70 backdrop-blur-xl p-4 flex items-center justify-center animate-in fade-in duration-300">
          <div className="w-full max-w-2xl h-[85vh] shadow-2xl rounded-[45px] overflow-hidden border border-white/10">
            <ChatWidget onClose={() => setShowChat(false)} />
          </div>
        </div>
      )}
    </div>
  );
};

const NavButton = ({ active, icon, label, onClick }: any) => (
  <button onClick={onClick} className={`flex flex-col items-center justify-center py-2 px-4 rounded-[28px] transition-all duration-300 ${active ? 'text-red-500 scale-110' : 'opacity-40 text-white hover:opacity-100'}`}>
    {icon}
    <span className={`text-[10px] font-black mt-1 transition-all ${active ? 'opacity-100' : 'opacity-0 h-0 overflow-hidden'}`}>{label}</span>
  </button>
);

export default App;
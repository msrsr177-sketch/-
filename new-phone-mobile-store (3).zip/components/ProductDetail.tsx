
import React, { useState, useEffect } from 'react';
import { DigitalProduct, ProductPackage } from '../types';
import { ChevronRight, Zap, ShieldCheck, CheckCircle2, ArrowLeft } from 'lucide-react';

interface ProductDetailProps {
  product: DigitalProduct;
  onBack: () => void;
}

const ProductDetail: React.FC<ProductDetailProps> = ({ product, onBack }) => {
  const [toast, setToast] = useState<{ show: boolean; pkgName: string | null }>({
    show: false,
    pkgName: null,
  });

  // تجميع الحزم حسب المجموعة إذا كانت موجودة
  const groups = product.packages.reduce((acc: Record<string, ProductPackage[]>, pkg) => {
    const groupName = pkg.group || 'default';
    if (!acc[groupName]) acc[groupName] = [];
    acc[groupName].push(pkg);
    return acc;
  }, {} as Record<string, ProductPackage[]>);

  const handlePackageSelect = (pkg: ProductPackage) => {
    setToast({ show: true, pkgName: pkg.amount });
  };

  useEffect(() => {
    if (toast.show) {
      const timer = setTimeout(() => {
        setToast((prev) => ({ ...prev, show: false }));
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [toast.show]);

  const renderPackage = (pkg: ProductPackage) => {
    const priceColor = pkg.color === 'cyan' ? 'text-sky-400' : 'text-[#FFD700]';

    return (
      <div 
        key={pkg.id} 
        onClick={() => handlePackageSelect(pkg)}
        className="glass-dark p-4 rounded-2xl flex items-center justify-between border border-white/5 hover:border-red-500/30 transition-all cursor-pointer group active:scale-[0.98]"
      >
        <div className="text-right">
          <div className="font-black text-xl text-white">{pkg.amount}</div>
          <div className={`${priceColor} font-black text-lg mt-1`}>{pkg.price}</div>
          <div className="text-white/20 text-[9px] mt-1">{pkg.name}</div>
        </div>
        <div className="flex items-center gap-4">
          <button className="maroon-gradient p-5 rounded-2xl group-hover:scale-110 transition-transform shadow-xl shadow-red-900/50 border border-white/10">
            <Zap className="w-7 h-7 text-white fill-current" />
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#1A0000] overflow-y-auto pb-32" dir="rtl">
      <div className="max-w-md mx-auto min-h-screen">
        {/* Header Image */}
        <div className="relative h-64">
          <img src={product.image} className="w-full h-full object-cover" alt={product.name} />
          <div className="absolute inset-0 bg-gradient-to-t from-[#1A0000] to-transparent" />
          <button 
            onClick={onBack}
            className="absolute top-6 right-6 glass p-2 rounded-full hover:bg-white/10"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="px-6 -mt-12 relative z-10 text-right">
          <div className="glass p-6 rounded-3xl border border-white/10 mb-8 shadow-2xl">
            <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
            <p className="text-white/60 text-sm mb-4 leading-relaxed">
              {product.description}
            </p>
            <div className="flex items-center gap-2 text-green-400 text-xs font-medium">
              <ShieldCheck className="w-4 h-4" />
              تسليم فوري ومضمون عبر الـ ID
            </div>
          </div>

          <div className="space-y-8">
            {(Object.entries(groups) as [string, ProductPackage[]][]).map(([groupName, packages]) => (
              <div key={groupName} className="space-y-4">
                {groupName !== 'default' && (
                  <h2 className={`text-xl font-black px-2 flex items-center gap-2 ${packages[0].color === 'cyan' ? 'text-sky-400' : 'text-[#FFD700]'}`}>
                    <div className={`w-2 h-6 rounded-full ${packages[0].color === 'cyan' ? 'bg-sky-400' : 'bg-[#FFD700]'}`}></div>
                    {groupName}
                  </h2>
                )}
                {groupName === 'default' && (
                  <h2 className="text-xl font-bold px-2">اختر الحزمة المناسبة</h2>
                )}
                <div className="grid gap-4">
                  {packages.map(renderPackage)}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Elegant Toast Notification */}
      <div className={`fixed bottom-8 left-4 right-4 z-[60] transition-all duration-500 transform ${toast.show ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0 pointer-events-none'}`}>
        <div className="max-w-md mx-auto glass-dark border border-white/10 p-4 rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.5)] flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-500/20 rounded-2xl flex items-center justify-center">
              <CheckCircle2 className="text-green-500 w-6 h-6" />
            </div>
            <div className="text-right">
              <p className="text-xs text-white/40 font-bold">تم الإضافة للسلة</p>
              <p className="text-sm font-black text-white">{toast.pkgName}</p>
            </div>
          </div>
          <button 
            onClick={() => alert('سيتم توجيهك لإكمال الطلب عبر واتساب')}
            className="maroon-gradient px-6 py-3 rounded-2xl font-black text-sm flex items-center gap-2 shadow-lg shadow-red-900/40 hover:scale-105 active:scale-95 transition-all"
          >
            إتمام الطلب
            <ArrowLeft className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;


import React from 'react';
import { DigitalProduct } from '../types';

interface ProductCardProps {
  product: DigitalProduct;
  onClick: (product: DigitalProduct) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onClick }) => {
  return (
    <div 
      onClick={() => onClick(product)}
      className="glass rounded-[30px] cursor-pointer group hover:scale-[1.03] transition-all duration-500 relative overflow-hidden flex flex-col items-center text-center h-full border border-white/10"
    >
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/10 to-black/70 z-10 opacity-60 group-hover:opacity-80 transition-opacity" />
      
      <div className="w-full aspect-video overflow-hidden relative border-b border-white/10">
        <img 
          src={product.image} 
          alt={product.name}
          className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700"
        />
        <div className="absolute top-2 right-2 glass-dark px-2.5 py-1 rounded-full text-[8px] font-black uppercase tracking-wider text-white border border-white/10 z-20">
          {product.category}
        </div>
      </div>
      
      <div className="flex-1 flex flex-col justify-between w-full p-3.5 relative z-20">
        <div className="mb-3">
          <h3 className="text-sm md:text-base font-black mb-1 group-hover:text-red-400 transition-colors line-clamp-1 leading-tight">{product.name}</h3>
          <p className="text-white/40 text-[9px] md:text-[10px] line-clamp-2 leading-relaxed px-1 font-medium">{product.description}</p>
        </div>
        
        <button className="w-full py-2.5 maroon-gradient rounded-xl font-black text-[10px] md:text-xs shadow-md hover:brightness-110 active:scale-95 transition-all">
          شحن الآن
        </button>
      </div>
    </div>
  );
};

export default ProductCard;

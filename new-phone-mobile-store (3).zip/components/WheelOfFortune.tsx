
import React, { useState } from 'react';
import { RefreshCw, Ticket, Lock, CheckCircle2, AlertCircle, Sparkles, Disc } from 'lucide-react';

const WheelOfFortune: React.FC = () => {
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [result, setResult] = useState<string | null>(null);
  const [code, setCode] = useState('');
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // الأكواد التي تسمح بالربح العشوائي
  const [validCodes, setValidCodes] = useState(['HK2BG7', 'F2V7IO']);
  // الأكواد التي تؤدي دائماً إلى الخسارة (حظ أوفر)
  const ALWAYS_LOSE_CODES = ['NEO100', 'H1M2D3'];

  const prizes = [
    "لاصق حماية", "كيبل شحن", "شاحن كامل", "رأس شحن", "سماعة محيطية", 
    "سماعة واير", "أيربود امريكي", "تخفيظ 20%", "تخفيض 10%", "تخفيض 50%", 
    "حظ أوفر", "حظ أوفر", "حظ أوفر", "حظ أوفر", "حظ أوفر", "حظ أوفر", "حظ أوفر", "حظ أوفر"
  ];

  const validateCode = () => {
    setError(null);
    const upperCode = code.toUpperCase();
    if (ALWAYS_LOSE_CODES.includes(upperCode)) {
      setIsUnlocked(true);
      return;
    }
    if (validCodes.includes(upperCode)) {
      setIsUnlocked(true);
    } else {
      setError('الكود غير صحيح');
    }
  };

  const spin = () => {
    if (isSpinning || !isUnlocked) return;
    setIsSpinning(true);
    setResult(null);

    let targetIndex: number;
    const upperCode = code.toUpperCase();
    
    if (ALWAYS_LOSE_CODES.includes(upperCode)) {
      // اختيار عشوائي لأحد فواصل "حظ أوفر"
      const loseIndices = prizes.map((p, i) => p === "حظ أوفر" ? i : -1).filter(i => i !== -1);
      targetIndex = loseIndices[Math.floor(Math.random() * loseIndices.length)];
    } else {
      targetIndex = Math.floor(Math.random() * prizes.length);
      // إزالة الكود المستخدم لمرة واحدة
      setValidCodes(prev => prev.filter(c => c !== upperCode));
    }

    const segmentAngle = 360 / prizes.length;
    const extraDegrees = (prizes.length - targetIndex) * segmentAngle;
    const newRotation = rotation + (360 * 5) + extraDegrees - (rotation % 360);
    
    setRotation(newRotation);
    
    setTimeout(() => {
      setIsSpinning(false);
      setResult(prizes[targetIndex]);
      setIsUnlocked(false);
      setCode('');
    }, 3000);
  };

  return (
    <div className="flex flex-col items-center justify-center p-6 md:p-8 glass rounded-[35px] text-center space-y-6 animate-in fade-in zoom-in duration-500 max-w-sm mx-auto border border-white/10 shadow-lg relative overflow-hidden">
      <div className="space-y-4">
        <div className="flex flex-col items-center gap-2">
          <div className="p-3 maroon-gradient rounded-full shadow-lg shadow-red-900/40 animate-pulse">
            <Disc className="text-white w-10 h-10" />
          </div>
          <h2 className="text-2xl font-black">عجلة الحظ</h2>
        </div>
        
        <div className="glass-dark p-4 rounded-2xl border border-white/5 space-y-2">
          <p className="text-[13px] text-white/90 leading-relaxed font-bold">
            شكراً لاختيارك نيو فون. بمناسبة تصليح جهازك، نقدملك كود "هدية الصيانة".
          </p>
          <p className="text-[12px] text-red-400 leading-relaxed font-medium">
            دخل الكود في تطبيقنا، فرّ العجلة، واستلم جائزتك فوراً من المحل. حظك اليوم يبتسم لك!
          </p>
        </div>
      </div>
      
      {!isUnlocked && !result ? (
        <div className="w-full space-y-3">
          <input 
            type="text" value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            placeholder="أدخل كود السحب"
            className="w-full bg-black/40 border border-white/10 rounded-xl py-4 text-center font-black tracking-widest text-base focus:outline-none focus:border-red-500/50 transition-all"
            maxLength={6}
          />
          {error && <div className="text-red-400 text-[10px] font-bold">{error}</div>}
          <button onClick={validateCode} className="w-full py-4 maroon-gradient rounded-xl font-black text-base shadow-md active:scale-95 transition-all">تفعيل الكود</button>
        </div>
      ) : null}

      <div className={`relative w-60 h-60 md:w-64 md:h-64 transition-opacity duration-500 ${!isUnlocked && !isSpinning && !result ? 'opacity-20 pointer-events-none grayscale' : 'opacity-100 scale-100 hover:scale-105'}`}>
        <div 
          className="w-full h-full rounded-full border-[8px] border-white/10 shadow-xl overflow-hidden relative transition-transform duration-[3000ms] cubic-bezier(0.15, 0, 0.15, 1)"
          style={{ transform: `rotate(${rotation}deg)` }}
        >
          {prizes.map((p, i) => (
            <div 
              key={i} 
              className="absolute top-0 left-1/2 w-1/2 h-1/2 origin-bottom-left flex items-start justify-center pt-4 border-l border-white/5"
              style={{ 
                transform: `rotate(${i * (360 / prizes.length)}deg)`, 
                backgroundColor: i % 2 === 0 ? 'rgba(128, 0, 0, 0.4)' : 'rgba(30, 0, 0, 0.7)' 
              }}
            >
              <span className="text-[7px] md:text-[8px] font-black uppercase -rotate-90 origin-center translate-y-6 whitespace-nowrap">
                {p}
              </span>
            </div>
          ))}
        </div>
        
        {/* Pointer */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-3 z-30 drop-shadow-md">
          <div className="w-0 h-0 border-l-[10px] border-l-transparent border-r-[10px] border-r-transparent border-t-[20px] border-t-white"></div>
        </div>
        
        <div className="absolute inset-0 m-auto w-12 h-12 glass rounded-full z-20 border-2 border-white/10 flex items-center justify-center font-black">
          <div className="text-red-500 text-[8px]">NEW</div>
        </div>
      </div>

      {result ? (
        <div className="flex flex-col items-center animate-bounce-short">
          <p className="text-[10px] text-white/40 mb-1 font-bold">النتيجة:</p>
          <div className="glass-dark px-6 py-3 rounded-2xl border border-red-500/30">
            <h3 className="text-2xl font-black text-red-400">{result}</h3>
          </div>
          <button 
            onClick={() => { setResult(null); setCode(''); setRotation(0); }}
            className="mt-6 px-8 py-2 glass rounded-xl text-[10px] font-bold hover:bg-white/5 transition-all"
          >
            جرب كود ثاني
          </button>
        </div>
      ) : isUnlocked ? (
        <button 
          onClick={spin}
          disabled={isSpinning}
          className={`px-12 py-4 maroon-gradient rounded-xl font-black text-lg shadow-lg flex items-center gap-2 ${isSpinning ? 'opacity-50 cursor-not-allowed' : 'hover:scale-105 active:scale-95'}`}
        >
          {isSpinning ? <RefreshCw className="animate-spin w-5 h-5" /> : 'ابدأ الحظ!'}
        </button>
      ) : null}
    </div>
  );
};

export default WheelOfFortune;

import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Loader2, X } from 'lucide-react';
import { Message } from '../types';
import { chatWithGemini } from '../services/gemini';

interface ChatWidgetProps {
  onClose?: () => void;
}

const ChatWidget: React.FC<ChatWidgetProps> = ({ onClose }) => {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: 'هلا بيك عيوني! شلون أكدر أخدمك اليوم؟' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;
    const userMessage: Message = { role: 'user', text: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);
    const history = messages.map(m => ({
      role: m.role,
      parts: [{ text: m.text }]
    }));
    const response = await chatWithGemini(input, history);
    setMessages(prev => [...prev, { role: 'model', text: response }]);
    setIsLoading(false);
  };

  return (
    <div className="flex flex-col h-full glass-dark md:rounded-[40px] overflow-hidden border border-white/10 shadow-[0_25px_50px_-12px_rgba(0,0,0,0.5)] relative" dir="rtl">
      {/* Decorative background glow inside the chat */}
      <div className="absolute top-0 left-1/4 w-64 h-64 bg-red-600/5 rounded-full blur-[100px] pointer-events-none"></div>
      <div className="absolute bottom-0 right-1/4 w-64 h-64 bg-red-900/10 rounded-full blur-[100px] pointer-events-none"></div>

      <div className="maroon-gradient p-4 flex items-center justify-between shadow-lg relative z-10 border-b border-white/5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 glass rounded-2xl flex items-center justify-center border border-white/20">
            <Bot size={22} className="text-white" />
          </div>
          <div className="text-right">
            <h3 className="font-black text-lg leading-tight text-white tracking-tight">المساعد الذكي</h3>
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span>
              <span className="text-[10px] font-bold uppercase tracking-widest text-white/60">متصل الآن</span>
            </div>
          </div>
        </div>
        {onClose && (
          <button 
            onClick={onClose} 
            className="glass hover:bg-white/10 p-2 rounded-xl transition-all active:scale-90 border border-white/10"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        )}
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-5 space-y-4 relative z-10 no-scrollbar">
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === 'user' ? 'justify-start' : 'justify-end'} animate-in fade-in slide-in-from-bottom-2 duration-300`}>
            <div className={`flex gap-3 max-w-[85%] ${msg.role === 'user' ? 'flex-row' : 'flex-row-reverse'}`}>
              <div className={`w-9 h-9 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg border ${
                msg.role === 'user' 
                  ? 'maroon-gradient border-white/10 text-white' 
                  : 'glass-dark border-red-500/20 text-red-500'
              }`}>
                {msg.role === 'user' ? <User size={18} /> : <Bot size={18} />}
              </div>
              <div className={`p-4 rounded-[22px] text-sm leading-relaxed text-right font-medium shadow-sm border ${
                msg.role === 'user' 
                  ? 'bg-red-900/20 text-white rounded-tl-none border-red-500/10' 
                  : 'glass rounded-tr-none border-white/5 text-white/90'
              }`}>
                {msg.text}
              </div>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-end animate-pulse">
            <div className="glass p-3 rounded-2xl rounded-tr-none flex items-center gap-3 border border-white/5">
              <Loader2 className="w-4 h-4 animate-spin text-red-500" />
              <span className="text-xs text-white/40 font-black italic">جاري التفكير...</span>
            </div>
          </div>
        )}
      </div>

      <div className="p-4 bg-white/5 backdrop-blur-xl border-t border-white/10 relative z-10">
        <div className="relative group">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="اكتب استفسارك هنا عيوني..."
            className="w-full bg-black/40 border border-white/10 rounded-2xl py-4 px-6 pl-14 text-right text-sm font-bold focus:outline-none focus:border-red-500/40 focus:ring-1 focus:ring-red-500/20 transition-all placeholder:text-white/20 text-white"
          />
          <button 
            onClick={handleSend}
            disabled={isLoading || !input.trim()}
            className="absolute left-2 top-2 bottom-2 aspect-square maroon-gradient rounded-xl flex items-center justify-center hover:scale-105 active:scale-95 disabled:opacity-30 disabled:grayscale transition-all shadow-lg shadow-red-900/20"
          >
            <Send className="w-5 h-5 rotate-180 text-white" />
          </button>
        </div>
        <p className="text-center text-[9px] text-white/20 mt-3 font-medium">الذكاء الاصطناعي قد يخطئ أحياناً، نيو فون بخدمتكم دائماً.</p>
      </div>
    </div>
  );
};

export default ChatWidget;